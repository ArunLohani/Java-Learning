enum Status {

    INPROGRESS,
    COMPLETED,
    CANCELLED,
    NEW
    }